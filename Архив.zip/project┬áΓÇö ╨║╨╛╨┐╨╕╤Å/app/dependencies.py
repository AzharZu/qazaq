from fastapi import Depends, HTTPException, Request, status

from app import models
from app.sessions import get_current_user_from_request


def get_current_user(request: Request) -> models.User:
    user = get_current_user_from_request(request)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_307_TEMPORARY_REDIRECT,
            headers={"Location": "/login"},
            detail="Not authenticated",
        )
    request.state.user = user
    return user


def require_admin(request: Request) -> models.User:
    user = get_current_user_from_request(request)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_307_TEMPORARY_REDIRECT,
            headers={"Location": "/login"},
            detail="Not authenticated",
        )
    if user.role != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin access required")
    request.state.user = user
    return user


def require_user(request: Request) -> models.User:
    user = get_current_user_from_request(request)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_307_TEMPORARY_REDIRECT,
            headers={"Location": "/login"},
            detail="Not authenticated",
        )
    request.state.user = user
    return user
