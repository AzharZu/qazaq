import os
from functools import lru_cache

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "Qazaq EdTech"
    secret_key: str = os.environ.get("SECRET_KEY", "devsecret")
    database_url: str = os.environ.get("DATABASE_URL", "sqlite:///./qazaq.db")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache
def get_settings() -> Settings:
    return Settings()
