from fastapi import Request

from app import models
from app.database import SessionLocal


def get_user_id_from_session(request: Request) -> int | None:
    if "session" not in request.scope:
        return None
    return request.session.get("user_id")


def get_current_user_from_request(request: Request) -> models.User | None:
    user_id = get_user_id_from_session(request)
    if not user_id:
        return None
    db = SessionLocal()
    try:
        return db.get(models.User, user_id)
    finally:
        db.close()


def set_user_session(request: Request, user: models.User) -> None:
    if "session" in request.scope:
        request.session["user_id"] = user.id
        request.session["age"] = user.age
        request.session["target"] = user.target


def clear_user_session(request: Request) -> None:
    if "session" in request.scope:
        request.session.clear()
