from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, selectinload

from app import models
from app.database import get_db

templates = Jinja2Templates(directory=str(Path(__file__).parent.parent / "templates"))

router = APIRouter(tags=["modules"])


@router.get("/course/{slug}/module/{module_id}")
async def module_page(slug: str, module_id: int, request: Request, db: Session = Depends(get_db)):
    module = (
        db.query(models.Module)
        .options(selectinload(models.Module.lessons))
        .filter(models.Module.id == module_id)
        .first()
    )
    course = db.query(models.Course).filter_by(slug=slug).first()
    if not module or not course or module.course_id != course.id:
        raise HTTPException(status_code=404, detail="Module not found")

    progress_map = {}
    user_id = request.session.get("user_id")
    if user_id:
        lesson_ids = [lesson.id for lesson in module.lessons]
        if lesson_ids:
            rows = (
                db.query(models.UserProgress)
                .filter(models.UserProgress.user_id == user_id, models.UserProgress.lesson_id.in_(lesson_ids))
                .all()
            )
            progress_map = {row.lesson_id: row.status for row in rows}

    return templates.TemplateResponse(
        "module_page.html",
        {"request": request, "module": module, "course": course, "progress_map": progress_map},
    )
