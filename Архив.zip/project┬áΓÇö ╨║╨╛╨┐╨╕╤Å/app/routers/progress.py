from pathlib import Path

from fastapi import APIRouter, Depends, Request
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, selectinload

from app import models
from app.database import get_db
from app.dependencies import get_current_user
from app.services import recommend_course_slug

templates = Jinja2Templates(directory=str(Path(__file__).parent.parent / "templates"))

router = APIRouter(tags=["progress"])


def _progress(db: Session, user_id: int, course: models.Course):
    lessons = [lesson for module in course.modules for lesson in sorted(module.lessons, key=lambda l: l.order)]
    lesson_ids = [l.id for l in lessons]
    if not lesson_ids:
        return {"percent": 0, "next": None, "done": 0, "total": 0, "minutes": 0, "map": {}}
    rows = (
        db.query(models.UserProgress)
        .filter(models.UserProgress.user_id == user_id, models.UserProgress.lesson_id.in_(lesson_ids))
        .all()
    )
    status_map = {row.lesson_id: row.status for row in rows}
    done = sum(1 for lid in lesson_ids if status_map.get(lid) == "done")
    minutes = sum(row.time_spent for row in rows)
    percent = int((done / len(lesson_ids)) * 100) if lesson_ids else 0
    next_lesson = next((l for l in lessons if status_map.get(l.id) != "done"), None)
    return {"percent": percent, "next": next_lesson, "done": done, "total": len(lesson_ids), "minutes": minutes, "map": status_map}


@router.get("/dashboard")
async def dashboard(request: Request, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    slug = request.session.get("course_slug") or recommend_course_slug(user.age, user.target)
    course = (
        db.query(models.Course)
        .options(selectinload(models.Course.modules).selectinload(models.Module.lessons))
        .filter_by(slug=slug)
        .first()
    )
    stats = {"percent": 0, "next": None, "done": 0, "total": 0, "minutes": 0}
    if course:
        stats = _progress(db, user.id, course)

    return templates.TemplateResponse(
        "dashboard.html",
        {
            "request": request,
            "course": course,
            "progress": stats["percent"],
            "next_lesson": stats["next"],
            "completed": stats["done"],
            "total": stats["total"],
            "remaining": max(stats["total"] - stats["done"], 0),
            "hours": round(stats["minutes"] / 60, 1) if stats["minutes"] else 0,
            "user": user,
        },
    )
