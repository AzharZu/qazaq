from pathlib import Path
from typing import List

from fastapi import APIRouter, Depends, Request, status
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app import models
from app.database import get_db
from app.services import compute_level, recommend_course_slug
from app.services.placement_questions import PLACEMENT_SECTIONS, get_sections_for_age

templates = Jinja2Templates(directory=str(Path(__file__).parent.parent / "templates"))

router = APIRouter(tags=["placement"])

LEVEL_DESCRIPTIONS = {
    "A0": "Стартовый уровень: знакомство с алфавитом и базовыми словами.",
    "A1": "Начинающий: понимаете простые фразы, умеете представиться.",
    "A2": "Элементарный: строите короткие фразы, спрашиваете дорогу, планируете день.",
    "B1": "Средний: поддерживаете беседу, понимаете тексты о работе/учёбе.",
    "B2": "Продвинутый: свободно читаете и общаетесь в большинстве ситуаций.",
}


def _load_user(request: Request, db: Session) -> models.User | None:
    user_id = request.session.get("user_id")
    if not user_id:
        return None
    return db.get(models.User, user_id)


def _build_questions(age: int | None) -> List[dict]:
    sections = get_sections_for_age(age)
    questions: List[dict] = []
    for section in sections:
        for q in section["questions"]:
            questions.append(
                {
                    "id": q["id"],
                    "question": q["question"],
                    "options": q["options"],
                    "correct": q["correct"],
                    "section": section["title"],
                }
            )
    return questions


@router.get("/placement-test")
async def placement_get(request: Request, db: Session = Depends(get_db)):
    user = _load_user(request, db)
    age = user.age if user else None

    sections = get_sections_for_age(age)
    questions = _build_questions(age)
    return templates.TemplateResponse(
        "placement/question.html",
        {
            "request": request,
            "sections": sections,
            "questions": questions,
            "total": len(questions),
            "age": age,
            "is_kid": age is not None and age <= 15,
            "error": None,
        },
    )


@router.post("/placement-test")
async def placement_submit(request: Request, db: Session = Depends(get_db)):
    user = _load_user(request, db)
    age = user.age if user else None

    sections = get_sections_for_age(age)
    questions = _build_questions(age)
    form = await request.form()

    answers = []
    missing = []
    score = 0
    for q in questions:
        raw_val = form.get(q["id"])
        if raw_val is None:
            missing.append(q["id"])
            continue
        try:
            selected = int(raw_val)
        except ValueError:
            missing.append(q["id"])
            continue
        is_correct = selected == q["correct"]
        answers.append({"id": q["id"], "selected": selected, "correct": q["correct"], "is_correct": is_correct})
        if is_correct:
            score += 1

    if missing:
        return templates.TemplateResponse(
            "placement/question.html",
            {
                "request": request,
                "sections": sections,
                "questions": questions,
                "total": len(questions),
                "age": age,
                "is_kid": age is not None and age <= 15,
                "error": "Пожалуйста, ответьте на все вопросы перед отправкой.",
            },
            status_code=status.HTTP_400_BAD_REQUEST,
        )

    total_questions = len(questions)
    normalized_score = level_score(score, total_questions)
    level = compute_level(score, total_questions)
    result_payload = {
        "score": normalized_score,
        "total": total_questions,
        "raw_score": score,
        "level": level,
    }
    request.session["placement_result"] = result_payload

    record = models.PlacementTestResult(
        user_id=user.id if user else None,
        level=level,
        score=normalized_score,
        answers={"questions": answers, "total": total_questions, "raw_score": score},
    )
    db.add(record)
    if user:
        user.level = level
        db.add(user)
    db.commit()

    return RedirectResponse("/placement-test/result", status_code=status.HTTP_302_FOUND)


def level_score(score: int, total_questions: int) -> int:
    from math import ceil

    if total_questions == 0:
        return 0
    if total_questions == 20:
        return score
    return ceil(score * 20 / total_questions)


@router.get("/placement-test/result")
async def placement_result(request: Request, db: Session = Depends(get_db)):
    result = request.session.get("placement_result")
    if not result:
        return RedirectResponse("/placement-test", status_code=status.HTTP_302_FOUND)

    user = _load_user(request, db)
    age = user.age if user else None
    target = user.target if user else None

    recommended_slug = recommend_course_slug(age, target)
    course = db.query(models.Course).filter_by(slug=recommended_slug).first()

    first_lesson = (
        db.query(models.Lesson)
        .join(models.Module, models.Module.id == models.Lesson.module_id)
        .filter(models.Module.course_id == (course.id if course else None))
        .order_by(models.Module.order, models.Lesson.order)
        .first()
        if course
        else None
    )

    start_url = f"/lesson/{first_lesson.id}" if first_lesson else (f"/course/{course.slug}" if course else "/courses")

    return templates.TemplateResponse(
        "placement_result.html",
        {
            "request": request,
            "level": result["level"],
            "score": result["score"],
            "total": result["total"],
            "description": LEVEL_DESCRIPTIONS.get(result["level"], ""),
            "course": course,
            "start_url": start_url,
        },
    )
