from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, selectinload

from app import models
from app.database import get_db
from app.services import recommend_course_slug

templates = Jinja2Templates(directory=str(Path(__file__).parent.parent / "templates"))

router = APIRouter(tags=["courses"])


@router.get("/")
async def index(request: Request, db: Session = Depends(get_db)):
    courses = db.query(models.Course).options(selectinload(models.Course.modules)).all()
    recommended_slug = request.session.get("course_slug") or recommend_course_slug(
        request.session.get("age"), request.session.get("target")
    )
    recommended = next((c for c in courses if c.slug == recommended_slug), courses[0] if courses else None)
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "courses": courses,
            "recommended": recommended,
        },
    )


@router.get("/courses")
async def courses_page(request: Request, db: Session = Depends(get_db)):
    courses = db.query(models.Course).all()
    return templates.TemplateResponse(
        "courses.html",
        {
            "request": request,
            "courses": courses,
        },
    )


def _calculate_progress(db: Session, user_id: Optional[int], course: models.Course):
    lesson_ids = [lesson.id for module in course.modules for lesson in module.lessons]
    if not lesson_ids:
        return 0, None, {}
    progress_rows = (
        db.query(models.UserProgress)
        .filter(models.UserProgress.user_id == user_id, models.UserProgress.lesson_id.in_(lesson_ids))
        .all()
        if user_id
        else []
    )
    progress_map = {row.lesson_id: row.status for row in progress_rows}
    completed = sum(1 for lid in lesson_ids if progress_map.get(lid) == "done")
    progress_percent = int((completed / len(lesson_ids)) * 100) if lesson_ids else 0

    next_lesson = None
    for module in course.modules:
        for lesson in module.lessons:
            if progress_map.get(lesson.id) != "done":
                next_lesson = lesson
                break
        if next_lesson:
            break
    if not next_lesson and course.modules and course.modules[0].lessons:
        next_lesson = course.modules[0].lessons[0]
    return progress_percent, next_lesson, progress_map


@router.get("/course/{slug}")
async def course_page(slug: str, request: Request, db: Session = Depends(get_db)):
    course = (
        db.query(models.Course)
        .options(selectinload(models.Course.modules).selectinload(models.Module.lessons))
        .filter(models.Course.slug == slug)
        .first()
    )
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")

    progress_percent, next_lesson, progress_map = _calculate_progress(db, request.session.get("user_id"), course)

    return templates.TemplateResponse(
        "course_page.html",
        {
            "request": request,
            "course": course,
            "progress": progress_percent,
            "next_lesson": next_lesson,
            "progress_map": progress_map,
        },
    )
