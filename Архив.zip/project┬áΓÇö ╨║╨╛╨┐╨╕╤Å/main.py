from app.main import app

# This file allows running `uvicorn main:app --reload` from the project root.
